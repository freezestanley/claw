# WebGen 预览体系重构设计

## 目标

在不破坏 OpenClaw 运行边界的前提下，重构 WebGen 的页面预览体系，使其同时满足以下目标：

- 预览入口统一且长期稳定
- 单页面项目默认低成本预览
- 远端接口请求可通过本地代理访问
- 未来支持需要编译的 React / Vite 项目
- 不引入第二套 session / project 真相源
- 不破坏 `一个 session = 一个项目` 的工作模型

本文档只描述预览体系设计，不包含代码实现细节。

## 背景与问题

当前预览体系的核心问题，不在于页面生成本身，而在于“每个项目自己直接托管一个 Vite 预览服务”的方式有以下缺陷：

- 项目级预览进程生命周期难以稳定管理
- `start / status / stop` 容易与真实进程状态脱节
- 端口分配、代理和健康检查都散落在项目脚本中
- 对纯静态单页来说，Vite 成本偏高
- 对未来 React 项目来说，又仍然离不开编译链

因此，问题本质不是“要不要 Vite”，而是“预览入口、代理能力、编译能力、项目隔离”应该如何分层。

## 设计结论

推荐采用：

- 一个常驻的 `Node Preview Gateway`
- 多个项目级按需激活的 `Preview Adapter`
- 对需要编译的项目，再按需启动“项目自己的 Vite 子进程”

明确不推荐两种方案：

### 方案 A：全面用 Node 替代 Vite

不推荐作为长期主方案。

原因：

- 可以解决静态资源服务和 `/api` 代理
- 但不能替代未来 React / Vite 项目的编译能力
- 最终仍然要再引入一层编译工具
- 会把问题从“预览托管”转移成“自己维护一套编译调度”

### 方案 B：整个 workspace 只维护一个共享 Vite

不推荐。

原因：

- Vite 天然是单工程上下文工具，不适合作为多项目共享网关
- 不同项目的 `root`、依赖、代理、alias、入口会互相污染
- 共享 Vite 会削弱项目隔离，违背当前 workspace 边界设计
- 随着模板增加，复杂度会迅速失控

### 方案 C：远端 Node 服务 + CORS 放开 + 页面直连远端接口

这是一个可选补充方案，但不应作为预览体系主方案。

其基本形式是：

- OpenClaw 内生成的页面直接请求某个远端 Node 服务
- 远端 Node 服务通过 CORS 允许预览来源跨域访问
- 远端 Node 服务再将请求分发到真实后端接口

这个方案本质上是“远端 BFF / API Gateway”，适合解决接口访问与跨域问题，但不适合承担页面预览与编译体系本身。

## 核心设计

### 一、分层结构

预览体系拆成三层：

#### 1. 常驻层：Preview Gateway

这是 workspace 级公共服务，只负责：

- 暴露统一预览入口
- 根据 `project-slug` 路由请求
- 读取项目 `.webgen/config.json`
- 执行静态资源托管
- 执行 `/api` 代理
- 在必要时托管项目级 Vite 子进程

Preview Gateway 不负责保存项目真相状态，不承担 session 持久化职责。

#### 2. 项目层：Project Preview Adapter

每个项目通过自己的 `.webgen/config.json` 声明预览模式和行为。

适配器职责：

- 告诉 Gateway 当前项目如何预览
- 告诉 Gateway `/api` 应代理到哪里
- 告诉 Gateway 项目是否需要 Vite 编译
- 告诉 Gateway 页面入口和挂载路径

项目的预览配置是真相源的一部分，必须仍然保存在项目目录内。

#### 3. 子进程层：On-demand Vite Worker

只有当项目本身需要编译时，才启动该项目自己的 Vite 进程。

这层职责是：

- 为需要编译的项目提供 dev server
- 保持编译上下文严格按项目隔离
- 由 Gateway 做生命周期托管

这一层不是常驻共享服务，而是按项目按需存在。

### 二、统一预览入口

建议所有项目统一通过 Gateway 访问，入口风格如下：

```text
/preview/<project-slug>/
/preview/<project-slug>/assets/...
/preview/<project-slug>/api/...
/preview/<project-slug>/__status
```

这样做的好处：

- 用户和 agent 只面对一个稳定入口
- 不需要感知项目内部是静态预览还是 Vite 预览
- 后续可以统一做状态检查、日志、调试和截图

### 三、双模式预览

每个项目的预览只允许两种模式：

#### `static`

适用于：

- 默认单页面项目
- HTML + CSS + JavaScript
- 以 CDN 为主的轻量页面
- 不依赖本地模块编译

行为：

- Gateway 直接托管项目目录中的页面和资源
- `/api` 请求由 Gateway 直接代理
- 不需要单独启动 Vite

#### `vite`

适用于：

- React 项目
- 需要编译、模块打包、热更新或更复杂构建链的项目

行为：

- Gateway 检查该项目的 Vite 子进程是否已启动
- 如未启动，按项目配置启动
- Gateway 再反向代理该项目的本地 dev server

### 五、远端 BFF 方案的定位

如果后续引入远端 Node 服务，建议只把它定义为：

- 远端 API BFF
- 远端接口分发层
- 远端鉴权 / 聚合 / 限流 / 缓存层

不建议把它定义为：

- 项目状态中心
- OpenClaw 外部的 session 中心
- 页面预览主入口
- 编译链托管中心

换句话说：

- 预览问题由本地 Preview Gateway 负责
- 接口分发问题可以交给远端 BFF 负责

两者可以协同，但不应混成一个系统

### 四、项目隔离原则

必须保持以下边界：

- 项目文件真相源只在 `projects/<slug>/`
- 项目文档和 `.webgen/config.json` 仍然只归当前 session 使用
- Gateway 可以读取多个项目，但不写入其它项目业务文件
- Gateway 的运行态缓存、临时 PID、内存索引不得成为项目状态真相源

换句话说：

- Gateway 是“运行设施”
- `projects/<slug>/` 才是“项目状态”

## 配置设计

建议对 `.webgen/config.json` 的 `preview` 段统一成如下语义：

```json
{
  "preview": {
    "mode": "static",
    "runtime": "gateway",
    "mountBase": "/preview/demo-site/",
    "entry": "/",
    "healthcheck": "/__status",
    "proxy": {
      "/api": {
        "target": "https://api.example.com",
        "changeOrigin": true,
        "secure": true
      }
    },
    "vite": {
      "enabled": false,
      "devCommand": "pnpm dev",
      "port": 4180
    }
  }
}
```

说明：

- `mode`
  - `static` 或 `vite`
- `runtime`
  - 对外统一由 Gateway 承载
- `mountBase`
  - 该项目在 Gateway 下的挂载基础路径
- `entry`
  - 页面入口
- `healthcheck`
  - 项目预览状态检查路径
- `proxy`
  - `/api` 代理目标
- `vite.enabled`
  - 标识是否需要项目级 Vite 子进程

如果项目采用远端 BFF，可在 `apis` 或 `preview.proxy` 中增加明确标识，例如：

- `apis.mode = remote-bff`
- `apis.baseUrl = https://your-bff.example.com`
- `apis.corsOrigin = <OpenClaw preview origin>`

不建议继续让每个项目把“对外预览地址”和“直接监听端口”作为主真相源。

更合理的模型是：

- 对外入口由 Gateway 统一
- 项目级端口只是内部运行态细节

## 请求链路

### 1. 静态项目

```text
Browser
  -> Gateway /preview/<slug>/
  -> 读取 projects/<slug>/.webgen/config.json
  -> 返回项目页面与静态资源
  -> /api 请求由 Gateway 代理到远端接口
```

特点：

- 不需要拉起项目级 dev server
- 启动成本最低
- 最适合当前“单页面 + CDN + JS-only”主路径

### 2. 需要编译的项目

```text
Browser
  -> Gateway /preview/<slug>/
  -> Gateway 读取项目配置
  -> 发现 mode=vite
  -> 检查项目级 Vite 子进程
  -> 如未运行则启动
  -> Gateway 反向代理到该项目 Vite 端口
  -> /api 请求继续由 Gateway 或 Vite 按统一规则代理
```

特点：

- 项目级编译能力仍被保留
- 对外入口不变
- Vite 不需要变成共享多租户服务

### 3. 采用远端 BFF 的项目

```text
Browser
  -> Gateway /preview/<slug>/
  -> 页面加载后直接请求远端 BFF
  -> 远端 BFF 按规则转发到真实后端
  -> BFF 返回统一格式数据给页面
```

特点：

- 适合把跨域、鉴权和接口聚合统一收口
- 本地预览服务不必承担复杂代理逻辑
- 但页面可用性会依赖远端 BFF 的在线状态

## 与 OpenClaw 约束的映射

### 符合点

- 仍然只在 OpenClaw workspace 内运行
- 不新建第二套 session 系统
- 仍然保持 `一个 session = 一个项目`
- 项目状态继续通过 Markdown 与 `.webgen/config.json` 恢复
- 页面开发与预览规则仍由项目目录驱动

### 必须注意的点

- Gateway 不能成为隐藏状态中心
- 不能把项目上下文只存在 Gateway 进程内存里
- 不能因为 Gateway 常驻就绕开项目级沙盒边界
- 与项目有关的可恢复信息，仍必须落回项目目录

对于远端 BFF 方案，还必须增加一条边界：

- 远端 BFF 不能承载 OpenClaw 内部的项目状态、会话状态和生成流程状态

## 对现有脚本体系的影响

现有脚本思路需要调整，但不是全部废弃。

### `project-preview.sh`

应从“直接启动和管理项目预览进程”，调整为：

- 注册项目到 Gateway
- 激活对应项目预览
- 输出统一预览地址

### `project-preview-status.sh`

应从“盯项目本地 PID 和端口”，调整为：

- 查询 Gateway 中该项目的状态
- 返回统一预览地址、模式、代理状态、子进程状态

### `project-preview-stop.sh`

应从“直接 kill 某个项目 dev server”，调整为：

- 请求 Gateway 释放该项目的运行态资源
- 如项目有 Vite 子进程，则由 Gateway 负责回收

### `project-package.sh`

与本次设计耦合较弱，可以保留项目级打包逻辑。

## 迁移策略

推荐分三阶段推进。

### 第一阶段：Gateway 接管静态预览

目标：

- 建立一个常驻 Node Preview Gateway
- 让默认单页面项目走 `static` 模式
- Gateway 负责统一路径和 `/api` 代理

收益：

- 立即减少“每项目独立起 Vite”的复杂度
- 先覆盖当前主路径

### 第二阶段：Gateway 托管项目级 Vite

目标：

- 为 `mode=vite` 项目增加子进程管理
- 支持启动、状态检查、超时回收、显式停止

收益：

- 保留未来 React 项目能力
- 不牺牲统一入口

### 第三阶段：脚本与文档全面切换

目标：

- 所有预览命令都改成面向 Gateway
- 文档、模板、状态字段全部与新模型一致
- 补齐验证、日志、故障排查说明

收益：

- 预览体系对用户和 agent 都变得可预测

## 成本与收益评估

### 收益

- 统一预览入口，用户心智简单
- 静态项目不必再为预览付出 Vite 成本
- React / Vite 项目仍然具备演进空间
- 项目隔离与预览统一可以同时成立
- 进程管理问题集中到 Gateway，而不是散落在每个项目脚本里

### 成本

- 需要额外实现一个 Node Gateway
- 需要调整现有预览脚本职责
- 需要为 Gateway 设计状态协议与回收策略
- 需要改造 `.webgen/config.json` 的 `preview` 语义

总体判断：

- 中期收益明显大于成本
- 比“共享一个 Vite”更稳
- 比“全面抛弃 Vite”更有演进余地

## 远端 BFF 方案评估

### 优点

- 页面接口调用更简单，不必每个项目都配置本地 `/api` 代理
- 对纯静态单页面很友好，即使只起静态服务也能访问接口
- 鉴权、签名、限流、缓存、重试、日志等能力可以集中治理
- 面对多个真实后端时，远端 BFF 可以统一协议和返回结构
- 多项目可复用同一套接口分发层

### 缺点

- 它只解决接口访问问题，不解决页面预览与编译问题
- 本地开发与演示会依赖远端服务的稳定性、网络与权限
- CORS 必须严格控制，不能粗暴全开放
- 调试链路会变长，问题可能出在页面、BFF 或真实后端任一层
- 如果职责边界失控，远端 BFF 容易演变成 OpenClaw 外部运行中枢

### 适用场景

- 已存在统一 API 网关或 BFF 团队能力
- 页面以单页展示为主，接口诉求相对集中
- 希望把鉴权和后端分发从前端页面移走
- 接受预览时依赖远端网络环境

### 不适用场景

- 希望离线或纯本地环境也能稳定预览
- 希望严格减少 OpenClaw 外部依赖
- 希望所有预览和运行能力都收口在 workspace 内
- 试图用远端 BFF 顺带替代本地预览、代理和编译体系

### 结论

远端 BFF 可以作为接口层补充方案纳入整体体系，但不应取代本地 Preview Gateway。

最合理的职责分工是：

- 本地 Preview Gateway 负责页面预览和必要的本地运行托管
- 远端 BFF 负责接口分发、跨域、鉴权和聚合

这样可以同时保留 OpenClaw 内部预览闭环，以及对复杂后端体系的适配能力。

## 风险点

- Gateway 如果设计过重，可能反而变成新的复杂中心
- 如果 `static` 与 `vite` 两套协议不统一，模板会分裂
- 如果项目级代理规则设计含糊，容易出现请求串项目
- 如果 Gateway 运行态信息不落回项目目录，恢复能力会下降

因此实现时必须坚持：

- Gateway 只做运行托管，不做项目真相源
- 项目恢复仍依赖项目目录
- 所有状态接口都要能解释“当前模式、当前代理、当前子进程”

## 验证标准

方案落地后，至少要满足以下验证条件：

### 静态项目

- 不启动 Vite 也能预览
- `/preview/<slug>/` 可访问
- `/preview/<slug>/api/*` 可代理
- 页面资源路径不串项目

### Vite 项目

- 首次访问时可按需启动项目级 Vite
- 对外入口仍保持统一
- 停止后能正确回收子进程
- 状态查询能区分“Gateway 正常 / 项目 Vite 未启动 / 项目 Vite 异常”

### OpenClaw 规范

- 不破坏 `一个 session = 一个项目`
- 不引入新的项目状态真相源
- 不跨项目写文件
- 仍然允许通过项目文档恢复上下文

## 建议的下一步

在本设计确认后，下一份文档应是实施计划，至少拆成以下部分：

1. Gateway 目录与文件结构
2. `.webgen/config.json` 的新字段设计
3. Gateway 的路由与状态接口
4. `project-preview*` 脚本迁移方案
5. `static` 模式模板改造方案
6. `vite` 模式子进程托管方案
7. 验证与回归清单
