(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))i(t);new MutationObserver(t=>{for(const r of t)if(r.type==="childList")for(const d of r.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&i(d)}).observe(document,{childList:!0,subtree:!0});function l(t){const r={};return t.integrity&&(r.integrity=t.integrity),t.referrerPolicy&&(r.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?r.credentials="include":t.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(t){if(t.ep)return;t.ep=!0;const r=l(t);fetch(t.href,r)}})();const j="SWIFT",o="#e11d2a";function k(e,a,l="#f5f5f5"){return`
  <svg viewBox="0 0 360 200" class="h-full w-full" role="img" aria-label="篮球鞋插画" preserveAspectRatio="xMidYMid meet">
    <defs>
      <linearGradient id="g-${e.replace("#","")}-${a.replace("#","")}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="${e}"/>
        <stop offset="1" stop-color="#0a0a0a"/>
      </linearGradient>
    </defs>
    <!-- 鞋底 -->
    <path d="M18 158 Q14 178 44 180 L320 180 Q344 180 342 162 L340 150 L26 150 Z"
          fill="${l}" stroke="#111" stroke-width="2"/>
    <rect x="20" y="150" width="320" height="6" fill="#222" opacity="0.35"/>
    <!-- 中底缓震点 -->
    <circle cx="70" cy="166" r="6" fill="${a}"/>
    <circle cx="300" cy="166" r="6" fill="${a}"/>
    <!-- 鞋身 -->
    <path d="M30 150 Q22 96 78 78 Q126 62 168 70 Q214 80 250 70 Q300 56 326 92 Q344 116 338 150 Z"
          fill="url(#g-${e.replace("#","")}-${a.replace("#","")})" stroke="#0a0a0a" stroke-width="2.5"/>
    <!-- 鞋舌/领口 -->
    <path d="M250 70 Q272 48 300 54 Q316 58 322 80 L318 96 Q296 78 268 84 Z" fill="${e}" stroke="#0a0a0a" stroke-width="2"/>
    <!-- 抽象 swoosh（非官方商标） -->
    <path d="M86 138 Q150 96 286 96 Q200 120 120 142 Q100 146 86 138 Z" fill="${a}"/>
    <!-- 鞋带区 -->
    <path d="M170 84 Q210 78 244 84 L240 116 Q206 110 176 114 Z" fill="#0a0a0a" opacity="0.55"/>
    <g stroke="${l}" stroke-width="3" opacity="0.85">
      <line x1="182" y1="92" x2="232" y2="98"/>
      <line x1="180" y1="102" x2="230" y2="108"/>
    </g>
  </svg>`}const y=[{id:"lb-eclipse",name:"Eclipse XXII",series:"LeBron 系列",price:1499,colorway:"黑曜 / 烈焰红",base:"#1a1a1a",accent:o,sole:"#f5f5f5"},{id:"lb-witness",name:"Witness Flow",series:"LeBron 系列",price:999,colorway:"纯白 / 赤红",base:"#3a3a3a",accent:"#ff3b30",sole:"#ffffff"},{id:"kd-tempo",name:"Tempo Lite",series:"KD 系列",price:1199,colorway:"暗夜黑 / 红线",base:"#141414",accent:"#d11a2a",sole:"#e8e8e8"},{id:"gt-cutter",name:"Cutter G3",series:"GT Cut 系列",price:1399,colorway:"竞速白 / 红勾",base:"#2b2b2b",accent:o,sole:"#ffffff"},{id:"freak-surge",name:"Surge Freak",series:"Giannis 系列",price:899,colorway:"炭黑 / 火山红",base:"#101010",accent:"#e02424",sole:"#f0f0f0"},{id:"mamba-strike",name:"Strike Mamba",series:"Mamba 经典",price:1599,colorway:"曜石黑 / 蛇红",base:"#0d0d0d",accent:"#c1121f",sole:"#efefef"}],m=e=>"¥"+e.toLocaleString("zh-CN");function N({container:e,runtime:a}){var M;const l=window.matchMedia("(prefers-reduced-motion: reduce)").matches,i=new Map;e.innerHTML=`
  <div class="min-h-screen bg-[#0a0a0a] font-sans text-white antialiased"
       style="font-family:-apple-system,'Segoe UI','Helvetica Neue',Arial,sans-serif;">

    <!-- 顶部导航 -->
    <header class="sticky top-0 z-30 border-b border-white/10 bg-black/85 backdrop-blur">
      <div class="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <a href="#" class="flex items-center gap-2">
          <svg viewBox="0 0 48 22" class="h-5 w-12" aria-hidden="true">
            <path d="M2 18 Q22 2 46 3 Q20 10 8 19 Q4 21 2 18 Z" fill="${o}"/>
          </svg>
          <span class="text-xl font-black tracking-tighter">${j}</span>
          <span class="ml-1 hidden text-[11px] font-semibold uppercase tracking-[0.3em] text-white/40 sm:inline">Basketball</span>
        </a>
        <nav class="hidden items-center gap-7 text-sm font-medium text-white/70 md:flex">
          <a href="#shop" class="transition hover:text-white">球鞋</a>
          <a href="#shop" class="transition hover:text-white">系列</a>
          <a href="#shop" class="transition hover:text-white">新品</a>
        </nav>
        <button id="open-cart"
          class="relative inline-flex h-11 min-w-[44px] items-center gap-2 rounded-full bg-white px-4 text-sm font-bold text-black transition active:scale-95">
          <i data-lucide="shopping-bag" class="h-5 w-5"></i>
          <span class="hidden sm:inline">购物袋</span>
          <span id="cart-badge"
            class="absolute -right-1 -top-1 hidden h-5 min-w-[20px] items-center justify-center rounded-full px-1 text-xs font-bold text-white"
            style="background:${o};">0</span>
        </button>
      </div>
    </header>

    <!-- Hero -->
    <section class="relative overflow-hidden border-b border-white/10">
      <div class="pointer-events-none absolute -right-24 top-1/2 hidden h-[420px] w-[420px] -translate-y-1/2 rounded-full opacity-30 blur-3xl md:block"
           style="background:radial-gradient(circle,${o},transparent 70%);"></div>
      <div class="mx-auto grid max-w-7xl items-center gap-8 px-4 py-12 sm:px-6 md:grid-cols-2 md:py-20 lg:px-8">
        <div class="space-y-6">
          <span class="inline-block rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-[0.25em]"
                style="border-color:${o};color:${o};">2026 Court Collection</span>
          <h1 class="text-5xl font-black leading-[0.95] tracking-tighter sm:text-6xl lg:text-7xl">
            为<span style="color:${o};">爆发力</span><br/>而生
          </h1>
          <p class="max-w-md text-base leading-7 text-white/70">
            从突破到终结，每一双都为球场上的关键时刻打造。轻量缓震，极致抓地。
          </p>
          <a href="#shop"
             class="inline-flex h-12 items-center rounded-full px-7 text-sm font-bold text-white transition active:scale-95"
             style="background:${o};">立即选购</a>
        </div>
        <div id="hero-shoe" class="relative mx-auto w-full max-w-md drop-shadow-2xl">
          ${k("#1a1a1a",o,"#ffffff")}
        </div>
      </div>
    </section>

    <!-- 商品列表 -->
    <section id="shop" class="mx-auto max-w-7xl px-4 py-12 sm:px-6 md:py-16 lg:px-8">
      <div class="mb-8 flex items-end justify-between">
        <div>
          <h2 class="text-3xl font-black tracking-tight sm:text-4xl">精选球鞋</h2>
          <p class="mt-1 text-sm text-white/50">经典系列 · 演示款式</p>
        </div>
        <span class="text-sm text-white/40">${y.length} 款</span>
      </div>
      <div id="product-grid" class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        ${y.map((s,n)=>O(s)).join("")}
      </div>
    </section>

    <!-- 页脚 -->
    <footer class="border-t border-white/10 bg-black">
      <div class="mx-auto max-w-7xl px-4 py-10 text-center sm:px-6 lg:px-8">
        <div class="mb-3 flex items-center justify-center gap-2">
          <svg viewBox="0 0 48 22" class="h-4 w-10" aria-hidden="true"><path d="M2 18 Q22 2 46 3 Q20 10 8 19 Q4 21 2 18 Z" fill="${o}"/></svg>
          <span class="text-lg font-black tracking-tighter">${j}</span>
        </div>
        <p class="mx-auto max-w-2xl text-xs leading-6 text-white/40">
          演示页面，与 Nike, Inc. 无任何关联。所有品牌名称、产品名称与图形均为虚构占位，仅用于前端交互演示，不构成任何销售要约。
        </p>
      </div>
    </footer>

    <!-- 购物袋抽屉 -->
    <div id="cart-overlay" class="fixed inset-0 z-40 hidden bg-black/60 backdrop-blur-sm"></div>
    <aside id="cart-drawer"
      class="fixed right-0 top-0 z-50 flex h-full w-full max-w-md translate-x-full flex-col bg-[#111111] shadow-2xl transition-transform duration-300 ease-out"
      role="dialog" aria-modal="true" aria-label="购物袋">
      <div class="flex items-center justify-between border-b border-white/10 px-5 py-4">
        <h3 class="text-lg font-black tracking-tight">购物袋</h3>
        <button id="close-cart" class="inline-flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition hover:bg-white/10 hover:text-white">
          <i data-lucide="x" class="h-5 w-5"></i>
        </button>
      </div>
      <div id="cart-items" class="flex-1 overflow-y-auto px-5 py-4"></div>
      <div class="border-t border-white/10 px-5 py-4">
        <div class="mb-3 flex items-center justify-between text-sm">
          <span class="text-white/60">小计</span>
          <span id="cart-total" class="text-xl font-black">¥0</span>
        </div>
        <button id="checkout-btn"
          class="h-12 w-full rounded-full text-sm font-bold text-white transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
          style="background:${o};" disabled>结算</button>
        <button id="clear-cart" class="mt-2 h-9 w-full text-xs font-medium text-white/40 transition hover:text-white/70">清空购物袋</button>
      </div>
    </aside>

    <!-- toast -->
    <div id="toast" class="pointer-events-none fixed bottom-6 left-1/2 z-[60] -translate-x-1/2 translate-y-4 rounded-full bg-white px-5 py-3 text-sm font-bold text-black opacity-0 shadow-2xl transition-all duration-300"></div>
  </div>`;const t=s=>e.querySelector(s),r=t("#cart-overlay"),d=t("#cart-drawer"),u=t("#cart-badge"),b=t("#cart-items"),S=t("#cart-total"),I=t("#checkout-btn"),p=t("#toast"),w=s=>y.find(n=>n.id===s);let $;function g(s){p.textContent=s,p.style.opacity="1",p.style.transform="translate(-50%, 0)",clearTimeout($),$=setTimeout(()=>{p.style.opacity="0",p.style.transform="translate(-50%, 1rem)"},1600)}function L(){let s=0;return i.forEach(n=>s+=n),s}function E(){let s=0;return i.forEach((n,c)=>s+=w(c).price*n),s}function x(){const s=L();s>0?(u.textContent=s,u.style.display="inline-flex"):u.style.display="none"}function h(){i.size===0?b.innerHTML=`
        <div class="flex h-full flex-col items-center justify-center gap-3 py-16 text-center text-white/40">
          <i data-lucide="shopping-bag" class="h-10 w-10"></i>
          <p class="text-sm">购物袋还是空的</p>
        </div>`:b.innerHTML=[...i.entries()].map(([s,n])=>{const c=w(s);return`
        <div class="mb-3 flex gap-3 rounded-2xl border border-white/10 bg-white/5 p-3">
          <div class="h-16 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-black/40">${k(c.base,c.accent,c.sole)}</div>
          <div class="min-w-0 flex-1">
            <p class="truncate text-sm font-bold">${c.name}</p>
            <p class="text-xs text-white/40">${c.series}</p>
            <p class="mt-1 text-sm font-bold" style="color:${o};">${m(c.price)}</p>
          </div>
          <div class="flex flex-col items-end justify-between">
            <button data-remove="${s}" class="text-white/30 transition hover:text-white" aria-label="移除">
              <i data-lucide="trash-2" class="h-4 w-4"></i>
            </button>
            <div class="flex items-center gap-1 rounded-full border border-white/15">
              <button data-dec="${s}" class="flex h-8 w-8 items-center justify-center text-white/70 transition hover:text-white" aria-label="减少">
                <i data-lucide="minus" class="h-3.5 w-3.5"></i>
              </button>
              <span class="w-5 text-center text-sm font-bold">${n}</span>
              <button data-inc="${s}" class="flex h-8 w-8 items-center justify-center text-white/70 transition hover:text-white" aria-label="增加">
                <i data-lucide="plus" class="h-3.5 w-3.5"></i>
              </button>
            </div>
          </div>
        </div>`}).join(""),S.textContent=m(E()),I.disabled=i.size===0,a.refreshIcons()}function B(s){var n;i.set(s,(i.get(s)||0)+1),x(),h(),g(`已加入 ${w(s).name}`),!l&&((n=window.anime)!=null&&n.animate)&&window.anime.animate(u,{scale:[1.4,1],duration:360,ease:"outBack"})}function C(){r.classList.remove("hidden"),requestAnimationFrame(()=>d.classList.remove("translate-x-full"))}function v(){d.classList.add("translate-x-full"),setTimeout(()=>r.classList.add("hidden"),280)}t("#open-cart").addEventListener("click",C),t("#close-cart").addEventListener("click",v),r.addEventListener("click",v),t("#clear-cart").addEventListener("click",()=>{i.clear(),x(),h(),g("已清空购物袋")}),t("#checkout-btn").addEventListener("click",()=>{g(`结算演示：${L()} 件 · ${m(E())}`)}),t("#product-grid").addEventListener("click",s=>{const n=s.target.closest("[data-add]");n&&B(n.getAttribute("data-add"))}),b.addEventListener("click",s=>{const n=s.target.closest("[data-inc]"),c=s.target.closest("[data-dec]"),T=s.target.closest("[data-remove]");if(n){const f=n.dataset.inc;i.set(f,i.get(f)+1)}else if(c){const f=c.dataset.dec,Q=i.get(f)-1;Q<=0?i.delete(f):i.set(f,Q)}else if(T)i.delete(T.dataset.remove);else return;x(),h()}),document.addEventListener("keydown",s=>{s.key==="Escape"&&!r.classList.contains("hidden")&&v()}),a.refreshIcons(),x(),h(),!l&&((M=window.anime)!=null&&M.animate)&&window.anime.animate(e.querySelectorAll(".product-card"),{opacity:[0,1],translateY:[24,0],delay:window.anime.stagger?window.anime.stagger(70):0,duration:600,ease:"outCubic"})}function O(e,a){return`
  <article class="product-card group flex flex-col overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-transparent">
    <div class="relative aspect-[16/10] overflow-hidden bg-[#161616]">
      <div class="absolute inset-0 flex items-center justify-center p-6 transition-transform duration-500 group-hover:scale-105">
        ${k(e.base,e.accent,e.sole)}
      </div>
      <span class="absolute left-3 top-3 rounded-full bg-black/60 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white/80">${e.series}</span>
    </div>
    <div class="flex flex-1 flex-col p-5">
      <h3 class="text-lg font-black tracking-tight">${e.name}</h3>
      <p class="mt-0.5 text-xs text-white/40">${e.colorway}</p>
      <div class="mt-4 flex items-end justify-between">
        <span class="text-xl font-black" style="color:${o};">${m(e.price)}</span>
        <button data-add="${e.id}"
          class="inline-flex h-11 min-w-[44px] items-center gap-1.5 rounded-full bg-white px-4 text-sm font-bold text-black transition active:scale-95 hover:bg-white/90">
          <i data-lucide="plus" class="h-4 w-4"></i>加入
        </button>
      </div>
    </div>
  </article>`}function P(e){return e.startsWith("http://")||e.startsWith("https://")||e.startsWith("/")?e:`/${e}`}async function A(e,a={}){var t;const l=P(e);if((t=window.axios)!=null&&t.get)return window.axios.get(l,a);const i=await fetch(l,{method:"GET"});if(!i.ok)throw new Error(`GET ${l} failed: ${i.status}`);return i}async function G(e,a,l={}){var r;const i=P(e);if((r=window.axios)!=null&&r.post)return window.axios.post(i,a,l);const t=await fetch(i,{method:"POST",headers:{"Content-Type":"application/json"},body:a===void 0?void 0:JSON.stringify(a)});if(!t.ok)throw new Error(`POST ${i} failed: ${t.status}`);return t}const H={template:"vite-page",pageMode:"single-page"},z={proxyPrefix:"/api",deviceTargets:["PC","Pad","H5"]};function R(){const e={current:null};return{project:H,preview:z,api:{get:A,post:G},refreshIcons(){var a;(a=window.lucide)!=null&&a.createIcons&&window.lucide.createIcons()},registerHealthNode(a){e.current=a},setHealthMessage(a,l="pending"){e.current&&(e.current.className=l==="ready"?"mt-4 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200":l==="warning"?"mt-4 rounded-2xl border border-amber-400/20 bg-amber-400/10 px-4 py-3 text-sm text-amber-100":"mt-4 rounded-2xl border border-sky-400/20 bg-sky-400/10 px-4 py-3 text-sm text-sky-100",e.current.textContent=a)}}}const Z=document.querySelector("#app"),q=R();N({container:Z,runtime:q});
