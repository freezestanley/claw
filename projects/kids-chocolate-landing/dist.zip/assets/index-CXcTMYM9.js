(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const c of document.querySelectorAll('link[rel="modulepreload"]'))i(c);new MutationObserver(c=>{for(const l of c)if(l.type==="childList")for(const t of l.addedNodes)t.tagName==="LINK"&&t.rel==="modulepreload"&&i(t)}).observe(document,{childList:!0,subtree:!0});function s(c){const l={};return c.integrity&&(l.integrity=c.integrity),c.referrerPolicy&&(l.referrerPolicy=c.referrerPolicy),c.crossOrigin==="use-credentials"?l.credentials="include":c.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function i(c){if(c.ep)return;c.ep=!0;const l=s(c);fetch(c.href,l)}})();const d=`
<svg viewBox="0 0 320 340" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="可可熊吉祥物">
  <ellipse cx="160" cy="318" rx="96" ry="16" fill="#4A2C18" opacity="0.12"/>
  <!-- 耳朵 -->
  <circle cx="86" cy="86" r="40" fill="#6B4226"/>
  <circle cx="86" cy="86" r="22" fill="#A9744F"/>
  <circle cx="234" cy="86" r="40" fill="#6B4226"/>
  <circle cx="234" cy="86" r="22" fill="#A9744F"/>
  <!-- 身体 -->
  <rect x="92" y="190" width="136" height="120" rx="56" fill="#6B4226"/>
  <!-- 肚皮 -->
  <ellipse cx="160" cy="252" rx="48" ry="50" fill="#F3DFC9"/>
  <!-- 可可豆胸标 -->
  <ellipse cx="160" cy="250" rx="16" ry="22" fill="#4A2C18"/>
  <path d="M160 232 v36" stroke="#A9744F" stroke-width="3" stroke-linecap="round"/>
  <!-- 头 -->
  <circle cx="160" cy="138" r="86" fill="#6B4226"/>
  <!-- 口鼻 -->
  <ellipse cx="160" cy="160" rx="48" ry="40" fill="#F3DFC9"/>
  <ellipse cx="160" cy="150" rx="13" ry="10" fill="#3A2417"/>
  <path d="M160 160 v14 M160 174 q-14 10 -26 2 M160 174 q14 10 26 2" stroke="#3A2417" stroke-width="4" stroke-linecap="round" fill="none"/>
  <!-- 眼睛 -->
  <circle cx="132" cy="120" r="10" fill="#3A2417"/>
  <circle cx="188" cy="120" r="10" fill="#3A2417"/>
  <circle cx="135" cy="116" r="3.5" fill="#FFF8EF"/>
  <circle cx="191" cy="116" r="3.5" fill="#FFF8EF"/>
  <!-- 腮红 -->
  <circle cx="112" cy="146" r="11" fill="#F0586B" opacity="0.5"/>
  <circle cx="208" cy="146" r="11" fill="#F0586B" opacity="0.5"/>
  <!-- 挥手的手臂 -->
  <g class="mascot-arm" style="transform-origin:236px 210px">
    <rect x="220" y="150" width="34" height="80" rx="17" fill="#6B4226" transform="rotate(28 236 200)"/>
    <circle cx="260" cy="150" r="20" fill="#A9744F"/>
  </g>
  <rect x="66" y="200" width="34" height="78" rx="17" fill="#6B4226"/>
  <circle cx="83" cy="282" r="19" fill="#A9744F"/>
  <!-- 脚 -->
  <ellipse cx="128" cy="306" rx="26" ry="18" fill="#A9744F"/>
  <ellipse cx="192" cy="306" rx="26" ry="18" fill="#A9744F"/>
</svg>`,x=`
<svg viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="可可熊">
  <circle cx="22" cy="22" r="13" fill="#6B4226"/><circle cx="58" cy="22" r="13" fill="#6B4226"/>
  <circle cx="40" cy="42" r="28" fill="#6B4226"/>
  <ellipse cx="40" cy="50" rx="16" ry="13" fill="#F3DFC9"/>
  <ellipse cx="40" cy="46" rx="5" ry="4" fill="#3A2417"/>
  <circle cx="30" cy="36" r="4" fill="#3A2417"/><circle cx="50" cy="36" r="4" fill="#3A2417"/>
  <circle cx="22" cy="48" r="5" fill="#F0586B" opacity="0.5"/><circle cx="58" cy="48" r="5" fill="#F0586B" opacity="0.5"/>
</svg>`,p=`
<svg viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <rect x="20" y="20" width="80" height="80" rx="10" fill="#6B4226"/>
  <rect x="20" y="20" width="80" height="80" rx="10" fill="url(#cg)" opacity="0.25"/>
  <g stroke="#4A2C18" stroke-width="4">
    <path d="M60 24 V96 M24 60 H96"/>
  </g>
  <g fill="#A9744F">
    <rect x="28" y="28" width="24" height="24" rx="4"/><rect x="68" y="28" width="24" height="24" rx="4"/>
    <rect x="28" y="68" width="24" height="24" rx="4"/><rect x="68" y="68" width="24" height="24" rx="4"/>
  </g>
  <defs><linearGradient id="cg" x1="20" y1="20" x2="100" y2="100"><stop stop-color="#fff"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>
</svg>`,n=`
<svg viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <ellipse cx="30" cy="30" rx="18" ry="24" fill="#4A2C18"/>
  <ellipse cx="30" cy="30" rx="11" ry="18" fill="#6B4226"/>
  <path d="M30 10 V50" stroke="#A9744F" stroke-width="3" stroke-linecap="round"/>
</svg>`,m=`
<svg viewBox="0 0 60 80" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <rect x="28" y="30" width="4" height="44" rx="2" fill="#A9744F"/>
  <circle cx="30" cy="22" r="20" fill="#F0586B"/>
  <path d="M30 22 m-14 0 a14 14 0 0 1 28 0" fill="none" stroke="#FFF8EF" stroke-width="3"/>
  <path d="M30 8 a14 14 0 0 1 12 20" fill="none" stroke="#FF9E45" stroke-width="3"/>
</svg>`,f=`
<svg viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <circle cx="30" cy="30" r="20" fill="#7FD4B6"/>
  <circle cx="30" cy="30" r="12" fill="#FFF8EF"/>
  <g stroke="#7FD4B6" stroke-width="3"><path d="M30 10 V20 M30 40 V50 M10 30 H20 M40 30 H50"/></g>
</svg>`;function h(a,e){return`
<svg viewBox="0 0 160 200" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="产品包装">
  <ellipse cx="80" cy="188" rx="56" ry="10" fill="#4A2C18" opacity="0.1"/>
  <path d="M40 30 Q40 18 52 18 H108 Q120 18 120 30 V178 Q120 188 108 188 H52 Q40 188 40 178 Z" fill="${a}"/>
  <path d="M40 30 Q40 18 52 18 H108 Q120 18 120 30 V70 H40 Z" fill="#FFFFFF" opacity="0.12"/>
  <rect x="52" y="6" width="56" height="16" rx="4" fill="${a}" opacity="0.8"/>
  <circle cx="80" cy="78" r="22" fill="#FFF8EF"/>
  <circle cx="72" cy="74" r="6" fill="#3A2417"/><circle cx="88" cy="74" r="6" fill="#3A2417"/>
  <ellipse cx="80" cy="86" rx="6" ry="4" fill="#3A2417"/>
  <rect x="56" y="118" width="48" height="10" rx="5" fill="${e}"/>
  <rect x="62" y="138" width="36" height="7" rx="3.5" fill="#FFF8EF" opacity="0.85"/>
</svg>`}const u=`
<svg viewBox="0 0 80 60" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <path d="M10 50 Q40 0 70 10 Q60 50 10 50 Z" fill="#7FD4B6"/>
  <path d="M14 48 Q42 24 66 14" stroke="#4A2C18" stroke-width="2.5" opacity="0.4" fill="none"/>
</svg>`,y=[{name:"牛奶可可熊",tag:"经典口味",desc:"顺滑牛奶可可，入口即化，孩子的第一块巧克力。",color:"#6B4226",accent:"#FF9E45"},{name:"榛子脆脆",tag:"酥脆颗粒",desc:"真实榛子碎，咔嚓一口，香气满满。",color:"#8A5A38",accent:"#F0586B"},{name:"莓莓夹心",tag:"果味夹心",desc:"草莓覆盆子夹心，酸甜平衡，不腻不齁。",color:"#F0586B",accent:"#FF9E45"},{name:"薄荷清新",tag:"清爽系列",desc:"一丝薄荷凉意，大孩子也爱的清新味。",color:"#7FD4B6",accent:"#6B4226"}],v=[{icon:n,title:"真实可可",desc:"选用真实可可脂与可可粉，不用代可可脂，味道更纯正。"},{icon:f,title:"低糖配方",desc:"比常见儿童巧克力减糖约 30%（示意），给甜味做减法。"},{icon:u,title:"无氢化油",desc:"配方中不添加氢化植物油与人工反式脂肪。"},{icon:m,title:"天然色香",desc:"不使用人工色素与香精，颜色与香气来自原料本身。"}],w=[{num:"8项",label:"出厂检测",note:"每批次重金属、微生物等多项检测（示意）。"},{num:"全标注",label:"过敏原透明",note:"含奶、坚果等过敏原在包装正面清晰标注。"},{num:"可溯源",label:"原料溯源",note:"可可豆产地与供应链信息可查（示意）。"}],b=[{q:"几岁的孩子可以吃？",a:"建议 3 岁以上、能自主咀嚼吞咽的孩子在家长看护下适量食用；具体请以包装说明与医嘱为准。"},{q:"含有哪些过敏原？",a:"产品含乳制品，部分系列含坚果（如榛子）。所有过敏原均在包装正面醒目标注，购买前请仔细查看。"},{q:"真的低糖吗？",a:"本页低糖等数据为演示示意，真实产品请以包装营养成分表为准。"},{q:"在哪里可以买到？",a:"本站为占位演示页，CTA 不进行真实下单。正式上线后将在此提供线上与线下购买渠道。"}],F=[["产品系列","#products"],["原料卖点","#points"],["安全营养","#safety"],["品牌故事","#story"],["购买与FAQ","#buy"]];function o(a,e){return`<span class="floaty pointer-events-none absolute ${e}" aria-hidden="true">${a}</span>`}function A(a){a.innerHTML=`
  <!-- NAV -->
  <header class="sticky top-0 z-40 border-b border-cocoa-100/70 bg-cream-100/85 backdrop-blur">
    <nav class="mx-auto flex h-16 max-w-[1200px] items-center justify-between px-4 sm:px-6 lg:px-8">
      <a href="#top" class="flex items-center gap-2">
        <span class="h-9 w-9">${x}</span>
        <span class="text-lg font-extrabold tracking-tight text-cocoa-700">可可熊 <span class="text-candy-orange">CocoBear</span></span>
      </a>
      <ul class="hidden items-center gap-7 text-sm font-semibold text-cocoa-600 lg:flex">
        ${F.map(([e,s])=>`<li><a href="${s}" class="transition hover:text-candy-red">${e}</a></li>`).join("")}
      </ul>
      <a href="#buy" class="inline-flex min-h-[44px] items-center rounded-full bg-cocoa-600 px-5 text-sm font-bold text-cream-50 shadow-lg shadow-cocoa-600/25 transition active:scale-95 hover:bg-cocoa-700">哪里购买</a>
    </nav>
  </header>

  <main id="top">
    <!-- HERO -->
    <section class="relative overflow-hidden bg-gradient-to-b from-cream-100 to-cream-200">
      ${o(p,"left-[4%] top-[14%] w-16 opacity-70 sm:w-20")}
      ${o(m,"right-[6%] top-[10%] w-12 opacity-80")}
      ${o(n,"bottom-[12%] left-[10%] w-10 opacity-70")}
      ${o(f,"right-[12%] bottom-[16%] w-12 opacity-70")}
      <div class="mx-auto grid max-w-[1200px] items-center gap-8 px-4 py-14 sm:px-6 md:py-20 lg:grid-cols-[1.05fr_0.95fr] lg:gap-6 lg:px-8">
        <div class="reveal text-center lg:text-left">
          <span class="inline-flex items-center gap-2 rounded-full bg-candy-mint/25 px-4 py-1.5 text-sm font-bold text-cocoa-600">
            🐻 为孩子用心 · 让家长放心
          </span>
          <h1 class="mt-5 text-4xl font-extrabold leading-tight tracking-tight text-cocoa-700 sm:text-5xl lg:text-6xl">
            每一口可可熊<br/>都是<span class="text-candy-red">甜甜的安心</span>
          </h1>
          <p class="mx-auto mt-5 max-w-md text-base leading-7 text-cocoa-500 sm:text-lg lg:mx-0">
            真实可可、低糖配方、原料透明。给孩子值得期待的味道，给家长看得明白的放心。
          </p>
          <div class="mt-8 flex flex-col items-center gap-3 sm:flex-row lg:justify-start">
            <a href="#products" class="inline-flex min-h-[48px] w-full items-center justify-center rounded-full bg-candy-orange px-7 text-base font-bold text-cocoa-800 shadow-xl shadow-candy-orange/30 transition active:scale-95 hover:brightness-105 sm:w-auto">了解更多</a>
            <a href="#buy" class="inline-flex min-h-[48px] w-full items-center justify-center rounded-full border-2 border-cocoa-300 bg-cream-50 px-7 text-base font-bold text-cocoa-600 transition active:scale-95 hover:border-cocoa-500 sm:w-auto">哪里购买</a>
          </div>
        </div>
        <div class="reveal relative mx-auto w-64 sm:w-80 lg:w-full lg:max-w-md">
          <div class="absolute inset-0 -z-10 scale-90 rounded-full bg-candy-mint/30 blur-2xl"></div>
          <span class="block floaty">${d}</span>
        </div>
      </div>
    </section>

    <!-- PRODUCTS -->
    <section id="products" class="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 md:py-24 lg:px-8">
      <div class="reveal max-w-xl">
        <h2 class="text-3xl font-extrabold tracking-tight text-cocoa-700 sm:text-4xl">四只小熊，四种好味道</h2>
        <p class="mt-3 text-cocoa-500">从经典牛奶到清新薄荷，总有一款合孩子的口味。</p>
      </div>
      <div class="mt-10 flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4 md:grid md:grid-cols-2 md:overflow-visible lg:grid-cols-4">
        ${y.map(e=>`
        <article class="reveal group min-w-[78%] snap-center rounded-4xl border border-cocoa-100 bg-cream-50 p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl hover:shadow-cocoa-600/10 sm:min-w-[60%] md:min-w-0">
          <div class="mx-auto w-28 transition group-hover:scale-105">${h(e.color,e.accent)}</div>
          <span class="mt-4 inline-block rounded-full bg-candy-mint/25 px-3 py-1 text-xs font-bold text-cocoa-600">${e.tag}</span>
          <h3 class="mt-2 text-xl font-extrabold text-cocoa-700">${e.name}</h3>
          <p class="mt-2 text-sm leading-6 text-cocoa-500">${e.desc}</p>
        </article>`).join("")}
      </div>
    </section>

    <!-- SELLING POINTS -->
    <section id="points" class="bg-cocoa-700 text-cream-50">
      <div class="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 md:py-24 lg:px-8">
        <div class="reveal max-w-xl">
          <h2 class="text-3xl font-extrabold tracking-tight sm:text-4xl">好吃，是因为用料实在</h2>
          <p class="mt-3 text-cream-200/80">我们在配料表上做加法，在糖和添加剂上做减法。</p>
        </div>
        <div class="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          ${v.map(e=>`
          <div class="reveal rounded-4xl bg-cream-50/5 p-6 ring-1 ring-cream-50/10">
            <span class="block h-14 w-14">${e.icon}</span>
            <h3 class="mt-4 text-lg font-extrabold">${e.title}</h3>
            <p class="mt-2 text-sm leading-6 text-cream-200/80">${e.desc}</p>
          </div>`).join("")}
        </div>
        <p class="reveal mt-6 text-xs text-cream-200/50">* 减糖比例等为演示示意，真实数据以产品包装营养成分表为准。</p>
      </div>
    </section>

    <!-- SAFETY (家长安心) -->
    <section id="safety" class="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 md:py-24 lg:px-8">
      <div class="grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]">
        <div class="reveal">
          <span class="inline-flex items-center gap-2 rounded-full bg-candy-mint/25 px-4 py-1.5 text-sm font-bold text-cocoa-600">家长安心区</span>
          <h2 class="mt-4 text-3xl font-extrabold tracking-tight text-cocoa-700 sm:text-4xl">把放心，写在看得见的地方</h2>
          <p class="mt-3 max-w-md leading-7 text-cocoa-500">孩子吃进嘴里的东西，值得每一道把关。我们把检测、过敏原与原料信息都摆到台面上。</p>
        </div>
        <div class="grid gap-4 sm:grid-cols-3">
          ${w.map(e=>`
          <div class="reveal rounded-4xl border border-cocoa-100 bg-cream-50 p-6 text-center shadow-sm">
            <p class="text-3xl font-extrabold text-candy-red">${e.num}</p>
            <p class="mt-1 font-bold text-cocoa-700">${e.label}</p>
            <p class="mt-2 text-xs leading-5 text-cocoa-500">${e.note}</p>
          </div>`).join("")}
        </div>
      </div>
    </section>

    <!-- STORY -->
    <section id="story" class="relative overflow-hidden bg-cream-200">
      ${o(n,"right-[8%] top-[18%] w-10 opacity-60")}
      ${o(p,"left-[6%] bottom-[14%] w-16 opacity-50")}
      <div class="mx-auto grid max-w-[1200px] items-center gap-8 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-[0.8fr_1.2fr] lg:px-8">
        <div class="reveal relative mx-auto w-48 sm:w-56">
          <div class="absolute inset-0 -z-10 scale-95 rounded-full bg-candy-orange/25 blur-2xl"></div>
          <span class="block floaty">${d}</span>
        </div>
        <div class="reveal">
          <h2 class="text-3xl font-extrabold tracking-tight text-cocoa-700 sm:text-4xl">可可熊的小故事</h2>
          <p class="mt-4 leading-8 text-cocoa-600">
            可可熊住在一片可可树林里，它最大的心愿，是让每个小朋友都能尝到刚刚好的甜。<br/>
            于是它挑最饱满的可可豆，把糖放得少一点、把用心放得多一点——希望孩子开心，也希望陪在身边的爸爸妈妈，能安心地说一句「这个可以吃」。
          </p>
          <p class="mt-4 text-sm text-cocoa-400">（可可熊 CocoBear 为演示占位品牌，故事与形象均为虚构。）</p>
        </div>
      </div>
    </section>

    <!-- BUY + FAQ -->
    <section id="buy" class="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 md:py-24 lg:px-8">
      <div class="reveal rounded-5xl bg-cocoa-600 px-6 py-12 text-center text-cream-50 sm:px-10">
        <h2 class="text-3xl font-extrabold tracking-tight sm:text-4xl">想让孩子尝一口可可熊？</h2>
        <p class="mx-auto mt-3 max-w-md text-cream-200/85">本站为演示占位页，按钮暂不进行真实下单。正式上线后这里将提供购买渠道。</p>
        <div class="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <button type="button" data-cta="buy" class="inline-flex min-h-[48px] w-full items-center justify-center rounded-full bg-candy-orange px-7 text-base font-bold text-cocoa-800 shadow-xl shadow-black/15 transition active:scale-95 hover:brightness-105 sm:w-auto">查看购买渠道</button>
          <button type="button" data-cta="more" class="inline-flex min-h-[48px] w-full items-center justify-center rounded-full border-2 border-cream-50/40 px-7 text-base font-bold text-cream-50 transition active:scale-95 hover:bg-cream-50/10 sm:w-auto">了解更多产品</button>
        </div>
        <p data-cta-hint class="mt-4 hidden text-sm text-candy-mint"></p>
      </div>

      <div class="mt-14 grid gap-8 lg:grid-cols-[0.6fr_1fr]">
        <h3 class="reveal text-2xl font-extrabold tracking-tight text-cocoa-700 sm:text-3xl">常见问题</h3>
        <div class="reveal divide-y divide-cocoa-100 rounded-4xl border border-cocoa-100 bg-cream-50">
          ${b.map(e=>`
          <details class="group px-5">
            <summary class="flex min-h-[56px] cursor-pointer list-none items-center justify-between gap-4 py-4 font-bold text-cocoa-700">
              <span>${e.q}</span>
              <span class="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-candy-mint/30 text-cocoa-600 transition group-open:rotate-45">+</span>
            </summary>
            <p class="pb-5 text-sm leading-6 text-cocoa-500">${e.a}</p>
          </details>`).join("")}
        </div>
      </div>
    </section>

    <!-- FOOTER -->
    <footer class="bg-cocoa-800 text-cream-200/80">
      <div class="mx-auto flex max-w-[1200px] flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
        <div class="flex items-center gap-2">
          <span class="h-9 w-9">${x}</span>
          <span class="text-lg font-extrabold text-cream-50">可可熊 CocoBear</span>
        </div>
        <p class="text-sm leading-6">
          本页为 WebGen 生成的演示占位站，可可熊 CocoBear 为虚构品牌，<br class="hidden sm:block"/>不含任何真实商标，按钮不进行真实交易。
        </p>
        <div class="flex gap-3" aria-label="社交媒体（占位）">
          ${["🐻","🍫","🍬"].map(e=>`<span class="grid h-10 w-10 place-items-center rounded-full bg-cream-50/10 text-lg">${e}</span>`).join("")}
        </div>
      </div>
      <p class="border-t border-cream-50/10 py-4 text-center text-xs text-cream-200/50">© 2026 CocoBear Demo · 仅供演示</p>
    </footer>
  </main>`,B()}function B(){const a=window.matchMedia("(prefers-reduced-motion: reduce)").matches,e=window.anime,s=e&&(e.animate||e);document.querySelectorAll("[data-cta]").forEach(t=>{t.addEventListener("click",()=>{const r=document.querySelector("[data-cta-hint]");if(!r)return;const g=t.getAttribute("data-cta");r.textContent=g==="buy"?"🛒 演示页：购买渠道将在正式上线后开放～":"👀 向上滚动即可查看四款可可熊产品系列～",r.classList.remove("hidden")})});const i=Array.from(document.querySelectorAll(".reveal"));if(a||!s||!("IntersectionObserver"in window))return;i.forEach(t=>t.classList.add("reveal-armed"));const c=t=>{t.classList.contains("reveal-armed")&&(t.classList.remove("reveal-armed"),s(t,{opacity:[0,1],translateY:[24,0],duration:650,easing:"easeOutCubic"}))},l=new IntersectionObserver(t=>{t.forEach(r=>{r.isIntersecting&&(c(r.target),l.unobserve(r.target))})},{threshold:.12,rootMargin:"0px 0px -8% 0px"});i.forEach(t=>l.observe(t)),setTimeout(()=>{document.querySelectorAll(".reveal-armed").forEach(t=>{t.classList.remove("reveal-armed"),t.style.opacity="1",t.style.transform="none"})},2200),s&&!a&&(s(".floaty",{translateY:[{value:-8,duration:1600},{value:0,duration:1600}],easing:"easeInOutSine",loop:!0,delay:(t,r)=>r*180}),document.querySelectorAll(".mascot-arm").forEach(t=>{s(t,{rotate:[0,18,0],duration:1400,easing:"easeInOutSine",loop:!0})}))}const $=document.querySelector("#app");A($);
